# poc-integration-service

# Datapower XML Merge deployment Code Work Flow

# Tekton Task

# Git Clone
1.	Excel structued  files
2.	Download the datapower deployment files repo

# Backup Process
1.	Input Excel structured data
2.	Generated structued merged json as ouput
3.	With the generated json download all the xml files & configuration
4.	update the downloaded xml files path into the merged JSON
5.	Push into Git up branch

# Merge delta files
1.	Input - Updated merged JSON , Download the datapower deployment files repo from Git
2.	Created a folder Pre-deployment-task-output & subfolder name as today's date
3.	Read the JSON values of  "DELTA_PATH","LOCAL_PATH", "Action_Type","XPath_or_Tag","Position","Match_Keys"
4.	Perform the task according to the action items & move into the folders (Ref step no : 2)
5.	In the subfolder structure should be "{CR}-"{Domain}"-"Delta"-{Module-Type}"-"{Target_Path}"-"{Target_Files}"
6.	update the status into correspoing rows on the excel sheet
7.	Finally push the changes along with the updated excel sheet into git up branch