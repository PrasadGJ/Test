import yaml
import argparse
from lxml import etree
import os


def load_yaml_to_dict(yaml_path):
    """Load nested 2-column YAML into a flat dictionary."""
    with open(yaml_path, "r") as f:
        raw = yaml.safe_load(f)

    # If YAML contains a nested list, flatten it
    if len(raw) == 1 and isinstance(raw[0], list):
        raw = raw[0]

    result = {}
    for row in raw:
        if len(row) != 2:
            continue  # ignore malformed rows
        key, value = row
        result[key] = value

    return result


def merge_xml(base_xml_path, delta_xml_path, xpath_exp, mode, output_path, namespaces):
    """Merge delta XML into base XML using XPath and chosen mode."""

    print(f"Loading base XML: {base_xml_path}")
    base_tree = etree.parse(base_xml_path)
    base_root = base_tree.getroot()

    print(f"Loading delta XML: {delta_xml_path}")
    delta_tree = etree.parse(delta_xml_path)
    delta_root = delta_tree.getroot()

    # Find merge target
    target_nodes = base_root.xpath(xpath_exp, namespaces=namespaces)
    if not target_nodes:
        raise Exception(f"❌ XPath not found: {xpath_exp}")

    target_node = target_nodes[0]

    # Find <dm:MAPPING> inside delta XML
    delta_mapping = delta_root.find("dm:MAPPING", namespaces=namespaces)
    if delta_mapping is None:
        raise Exception("❌ <dm:MAPPING> not found in delta XML")

    # Insert children of <dm:MAPPING> (not the <dm:MAPPING> itself)
    if mode.lower() == "insert first":
        for child in reversed(delta_mapping):
            target_node.insert(0, child)
    else:
        raise ValueError(f"Unsupported merge mode: {mode}")

    # Ensure directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # Save merged XML
    base_tree.write(
        output_path,
        pretty_print=True,
        xml_declaration=False,
        encoding="UTF-8"
    )

    print(f"✔ Final merged XML saved to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="XML Merge Utility")
    parser.add_argument("--yaml", required=True, help="Path to YAML file")

    args = parser.parse_args()
    yaml_path = args.yaml

    # Load YAML
    info = load_yaml_to_dict(yaml_path)

    DOMAIN = info["DOMAIN"]
    TARGET_PATH = info["TARGET_PATH"]
    MODE = info["MODE"]
    DELTA_PATH = info["DELTA_PATH"]
    ACTION = info["ACTION"]

    if ACTION.lower() != "merge xml":
        raise Exception("❌ Only 'Merge XML' is supported")

    # BASE_XML = DOMAIN/TARGET_PATH
    BASE_XML = os.path.join(DOMAIN, TARGET_PATH)
    FINAL_XML = BASE_XML

    namespaces = {"dm": "http://www.ejada.com/DATA_MAPPING/"}
    XPATH = "./dm:MAPPING"

    merge_xml(
        base_xml_path=BASE_XML,
        delta_xml_path=DELTA_PATH,
        xpath_exp=XPATH,
        mode=MODE,
        output_path=FINAL_XML,
        namespaces=namespaces
    )


if __name__ == "__main__":
    main()
