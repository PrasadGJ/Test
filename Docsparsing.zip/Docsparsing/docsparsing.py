from docx import Document
import yaml


def docx_table_to_yaml(docx_path, yaml_path):
    # Load the .docx file
    document = Document(docx_path)

    all_tables_yaml = []

    # Loop through each table
    for table in document.tables:
        table_data = []

        # Extract rows
        for row in table.rows:
            row_data = [cell.text.strip() for cell in row.cells]
            table_data.append(row_data)

        all_tables_yaml.append(table_data)

    # Save as YAML
    with open(yaml_path, "w") as f:
        yaml.dump(all_tables_yaml, f, sort_keys=False, allow_unicode=True)

    print(f"YAML saved to {yaml_path}")

# Example usage:
docx_table_to_yaml("DataPower_table1.docx", "output.yaml")
