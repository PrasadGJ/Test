import os
import zipfile

def unzip_recursive(zip_file_path, base_extract_dir, delete_zip=False):
    """
    Recursively unzip ZIP files including ZIPs inside ZIPs.

    Args:
        zip_file_path (str): Path to the main ZIP file
        base_extract_dir (str): Base directory to extract files
        delete_zip (bool): Whether to delete ZIP after extraction

    Returns:
        str: Root extracted directory
    """
    if not os.path.exists(zip_file_path):
        raise FileNotFoundError(f"ZIP file not found: {zip_file_path}")

    zip_name = os.path.splitext(os.path.basename(zip_file_path))[0]
    extract_root = os.path.join(base_extract_dir, zip_name)
    os.makedirs(extract_root, exist_ok=True)

    def _extract(zip_path, extract_to):
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)

        if delete_zip:
            os.remove(zip_path)

        # Search for nested ZIPs
        for root, _, files in os.walk(extract_to):
            for file in files:
                if file.lower().endswith(".zip"):
                    nested_zip_path = os.path.join(root, file)
                    nested_name = os.path.splitext(file)[0]
                    nested_extract_dir = os.path.join(root, nested_name)

                    os.makedirs(nested_extract_dir, exist_ok=True)
                    _extract(nested_zip_path, nested_extract_dir)

    _extract(zip_file_path, extract_root)

    print(f"All ZIPs extracted successfully into: {extract_root}")
    return extract_root



