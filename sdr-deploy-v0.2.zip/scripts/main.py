import os
import glob
import json
import argparse

from openpyxl.styles.builtins import output

from sdr_files_merge import process_sdr_entry
from uncompressed import unzip_recursive
from excel_parser import parse_excel_sheet_rows

def main(release_date):
    backup_zip = "../Backup.zip"
    unzip_dir = "../original"


    excel_file = "../DP-Deployment-steps.xlsx"
    excel_sheet = release_date



    print("🔹 Unzipping backup files...")
    #unzip_recursive(backup_zip, unzip_dir)
    print("✔ Unzip completed.")

    print(f"🔹 Parsing Excel sheet '{excel_sheet}'...")
    #output_dir = parse_excel_sheet_rows(excel_file, excel_sheet)
    #print(f"✔ Excel parsed. JSON files stored in: {output_dir}")

    # For testing since delta path incorrect
    output_dir = "extracted_excel_data/"



    json_files_pattern = os.path.join(output_dir, "*.json")
    json_files = glob.glob(json_files_pattern)
    if not json_files:
        print(f"❌ No JSON files found in {output_dir}. Exiting.")
        return

    print("🔹 Fetching module types...")

    for json_file_path in json_files:
        if not os.path.exists(json_file_path):
            print(f"❌ File not found: {json_file_path}")
            continue

        with open(json_file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Ensure data is a list
        if isinstance(data, dict):
            data = [data]

        for item in data:
            module_type = item.get("Module_Type", "").strip().upper()
            target_files = item.get("Target_Files", "").strip().upper()
            if module_type == "SDR" and target_files == "DATA_MAPPING.XML":
                domain = item.get("Target_Domain", "").strip()
                target_path = "local/SDR/"
                target_files = item.get("Target_Files", "").strip()
                delta_path = item.get("Delta_Path", "").strip()
                action = item.get("Action_Type", "").strip()
                xpath = "dm:DATA_MAPPING/dm:MAPPING"
                position = "first"

                print("*" * 50)
                print(f"Target Path: {target_path}")
                print(f"Target Files: {target_files}")
                print(f"Delta Path: {delta_path}")
                print(f"Action: {action}")
                print(f"XPath: {xpath}")
                print(f"Position: {position}")


                process_sdr_entry(
                    release_date,
                    domain,
                    target_path,
                    target_files,
                    delta_path,
                    action,
                    xpath,
                    position)

    print("*" * 50)
    print("✔ All SDR entries processed.")





if __name__ == "__main__":
    parser = argparse.ArgumentParser()  # No description

    parser.add_argument(
        "--release_date",
        required=True,
        help="Release date to associate with datapower, e.g., 15-12-2025"
    )
    args = parser.parse_args()
    main(release_date=args.release_date)
