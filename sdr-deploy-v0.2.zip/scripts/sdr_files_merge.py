import json
import os
import shutil
from datetime import datetime
import xml.etree.ElementTree as ET
from lxml import etree

TODAY_FOLDER = None



def validate_xml_wellformed(xml_file_path):
    """
    Validate if an XML file is well-formed.

    Args:
        xml_file_path (str): Path to XML file

    Returns:
        bool: True if well-formed, False otherwise
    """
    try:
        ET.parse(xml_file_path)
        #print(f"XML is well-formed: {xml_file_path}")
        return True
    except ET.ParseError as e:
        #print(f"XML is NOT well-formed: {xml_file_path}\nError: {e}")
        return False

def get_today_folder(folder_name:str):
    """Return the folder for today's date; create it only once."""
    global TODAY_FOLDER
    if TODAY_FOLDER is None:
        TODAY_FOLDER = os.path.join(os.getcwd(), folder_name)
        os.makedirs(TODAY_FOLDER, exist_ok=True)
        print(f"Created folder: {TODAY_FOLDER}")
    return TODAY_FOLDER

def find_file_in_subfolders(root_folder, filename):
    """
    Search recursively in root_folder for filename.
    Returns the first full path found, else None.
    """
    for dirpath, _, files in os.walk(root_folder):
        if filename in files:
            return os.path.join(dirpath, filename)
    return None

def process_sdr_entry(deployment_release_date,domain, target_path, target_files, delta_path,action,xpath,position):
    """
    Example function to process SDR module entries.

    Args:
        localfilepath (str)
        target_path (str)
        target_files (str)
        delta_path (str)
    """

    today_folder = get_today_folder(deployment_release_date)

    nested_folder = os.path.join(today_folder, domain, "delta", target_path)
    os.makedirs(nested_folder, exist_ok=True)
    print(f"Created nested folder: {nested_folder}")


    original_file_path = os.path.join("../","original", "Backup",domain,target_path)
    delta_file_path = os.path.join("../","datapower-prod86", "Deployment","Deployment Packages",delta_path)


    complete_local_file_path = os.path.join(original_file_path, target_files)

    if not os.path.exists(complete_local_file_path):
        print(f"Original file not found: {complete_local_file_path}")
        return

    copied_file_path = os.path.join(nested_folder, target_files)
    if not os.path.exists(copied_file_path):
        shutil.copy2(complete_local_file_path, copied_file_path)
        print(f"Copied {complete_local_file_path} -> {copied_file_path}")
    else:
        print(f"File already copied: {copied_file_path}")

    #corrected_delta_path = delta_file_path.replace("/local/", "/")
    #corrected_delta_path = corrected_delta_path.replace("/Artifacts/", "/")

    corrected_delta_path = delta_file_path

    if os.path.isfile(corrected_delta_path):
        print(f"File exists: {corrected_delta_path}")
    else:
        print(f"File does NOT exist: {corrected_delta_path}")
        return

    org_file_path = copied_file_path
    deploy_action_file_path = corrected_delta_path

    print(f"org_file_path: {org_file_path}")
    print(f"deploy_action_file_path : {deploy_action_file_path}")

    if validate_xml_wellformed(org_file_path):
        print("Original XML is valid.")
    else:
        print("Original XML has errors!")
        return

    # Validate deployed/modified XML
    if validate_xml_wellformed(deploy_action_file_path):
        print("Deployment Release XML is valid.")
    else:
        print("Deployment Release XML has errors!")
        return

    if action == "Append" :
        # Validate delta entries
        results = validate_delta_entries(org_file_path, deploy_action_file_path, xpath)
        if not results:  # Missing entries or validation failed
            print("Delta validation failed. Merge aborted.")
            return False

        # Append delta XML to original
        append_delta_to_original(
            original_xml_path=org_file_path,
            delta_xml_path=deploy_action_file_path,
            output_path=org_file_path,
            position=position
        )

        # Validate merged XML
        if validate_xml_wellformed(org_file_path):
            print("Merged XML is valid.")
            return True
        else:
            print("Merged XML has errors!")
            return False

    if action == "Modify":
        results = validate_delta_entries(org_file_path, deploy_action_file_path, xpath)
        if not results:  # Missing entries or validation failed
            print("Delta validation failed. Merge aborted.")
            return False
        update_status = replace_original_entry_if_3_match(org_file_path, deploy_action_file_path)
        if not update_status: print("No updates or modified on the XML files")
        else: print("Modified on the XML files")
        if validate_xml_wellformed(org_file_path):
            print("Modified XML is valid.")
            return True
        else:
            print("Modified XML has errors!")
            return False
    if action == "Delete":
        results = validate_delta_entries(org_file_path, deploy_action_file_path, xpath)
        if not results:
            print("Delta validation failed. Merge aborted.")
            return False
        delete_status = delete_original_entry_only_if_all_fields_match(org_file_path, deploy_action_file_path)
        if not delete_status:
            print("No deleting on the XML files")
        else:
            print("Deleted on the XML files")
        if validate_xml_wellformed(org_file_path):
            print("Deleted XML is valid.")
            return True
        else:
            print("Deleted XML has errors!")
            return False


def replace_original_entry_if_3_match(original_xml_path, delta_xml_path):
    """
    Replace original <dm:RegexMapEntry> with delta entry
    if ANY 3 out of 5 child values match.

    Matching fields:
      Regex, ServiceURI, OperationName, ServiceName, HttpMethod
    """

    ns = {'dm': 'http://www.ejada.com/DATA_MAPPING/'}
    fields = ["Regex", "ServiceURI", "OperationName", "ServiceName", "HttpMethod"]

    output_xml_path = original_xml_path

    original_tree = etree.parse(original_xml_path)
    delta_tree = etree.parse(delta_xml_path)

    original_root = original_tree.getroot()

    # Get original and delta entries
    original_entries = original_tree.xpath("//dm:MAPPING/dm:RegexMapEntry", namespaces=ns)
    delta_entries = delta_tree.xpath("//dm:MAPPING/dm:RegexMapEntry", namespaces=ns)

    if not delta_entries:
        print("❌ No RegexMapEntry found in Delta XML")
        return False

    replaced = False

    for delta_entry in delta_entries:
        delta_values = {
            f: (delta_entry.findtext(f"dm:{f}", default="", namespaces=ns) or "").strip()
            for f in fields
        }

        for org_entry in original_entries:
            org_values = {
                f: (org_entry.findtext(f"dm:{f}", default="", namespaces=ns) or "").strip()
                for f in fields
            }

            # Count matching fields
            match_count = sum(
                1 for f in fields
                if delta_values[f] and delta_values[f] == org_values[f]
            )

            if match_count >= 3:
                parent = org_entry.getparent()
                index = parent.index(org_entry)

                # Replace original with delta (deep copy)
                new_entry = etree.fromstring(etree.tostring(delta_entry))
                parent.remove(org_entry)
                parent.insert(index, new_entry)

                print(f"✅ Replaced entry (matched {match_count} fields): {delta_values}")
                replaced = True
                break  # Stop after first match

    if replaced:
        original_tree.write(
            output_xml_path,
            pretty_print=True,
            xml_declaration=True,
            encoding="utf-8"
        )
        print(f"✔ Updated XML written to: {output_xml_path}")
        return True
    else:
        print("❌ No entry matched ≥ 3 fields. No replacement done.")
        return False


from lxml import etree

def delete_original_entry_only_if_all_fields_match(
    original_xml_path,
    delta_xml_path):
    """
    Deletes <dm:RegexMapEntry> from original XML ONLY IF
    ALL 5 fields match exactly with delta XML entry.
    """


    ns = {'dm': 'http://www.ejada.com/DATA_MAPPING/'}
    fields = ["Regex", "ServiceURI", "OperationName", "ServiceName", "HttpMethod"]

    output_xml_path = original_xml_path

    original_tree = etree.parse(original_xml_path)
    delta_tree = etree.parse(delta_xml_path)

    original_entries = original_tree.xpath(
        "//dm:MAPPING/dm:RegexMapEntry", namespaces=ns
    )
    delta_entries = delta_tree.xpath(
        "//dm:MAPPING/dm:RegexMapEntry", namespaces=ns
    )

    if not delta_entries:
        print("❌ Delta XML has no RegexMapEntry")
        return False

    deleted = False

    for delta_entry in delta_entries:
        delta_values = {
            f: (delta_entry.findtext(f"dm:{f}", "", namespaces=ns)).strip()
            for f in fields
        }

        for org_entry in list(original_entries):  # Safe iteration
            org_values = {
                f: (org_entry.findtext(f"dm:{f}", "", namespaces=ns)).strip()
                for f in fields
            }

            # STRICT MATCH: all fields must match
            if all(delta_values[f] == org_values[f] for f in fields):
                parent = org_entry.getparent()
                parent.remove(org_entry)

                print("🗑️ Deleted EXACT matching entry:")
                for k, v in delta_values.items():
                    print(f"   {k}: {v}")

                deleted = True
                break  # Delete only the exact match

    if deleted:
        original_tree.write(
            output_xml_path,
            pretty_print=True,
            xml_declaration=True,
            encoding="utf-8"
        )
        print(f"✔ XML updated: {output_xml_path}")
        return True

    print("❌ No EXACT match found. Nothing deleted.")
    return False


def validate_delta_entries(original_xml_path, delta_xml_path, parent_xpath):
    """
    Validate that all <dm:RegexMapEntry> in Delta XML exist in Original XML.

    Args:
        original_xml_path (str): Path to original XML
        delta_xml_path (str): Path to delta XML
        parent_xpath (str): XPath to <dm:MAPPING>, e.g., 'dm:DATA_MAPPING/dm:MAPPING'

    Returns:
        missing_entries (list): List of missing entries
    """
    ns = {'dm': 'http://www.ejada.com/DATA_MAPPING/'}  # Replace with actual namespace

    # Parse XML files
    try:
        original_tree = etree.parse(original_xml_path)
    except (etree.XMLSyntaxError, OSError) as e:
        print(f"Original XML cannot be parsed: {original_xml_path}\nError: {e}")
        return None

    try:
        delta_tree = etree.parse(delta_xml_path)
    except (etree.XMLSyntaxError, OSError) as e:
        print(f" Delta XML cannot be parsed: {delta_xml_path}\nError: {e}")
        return None


    xpath_expr = "//dm:MAPPING/dm:RegexMapEntry"
    # Attempt to find delta entries
    delta_entries = delta_tree.xpath(xpath_expr, namespaces=ns)
    if not delta_entries:
        print(f"No RegexMapEntry found in Delta XML. "
              f"Check XPath '{parent_xpath}' and namespace.")
        return None

    missing_entries = []

    for entry in delta_entries:
        # Extract child values
        delta_values = {
            'Regex': (entry.findtext('dm:Regex', default='', namespaces=ns) or '').strip(),
            'ServiceURI': (entry.findtext('dm:ServiceURI', default='', namespaces=ns) or '').strip(),
            'OperationName': (entry.findtext('dm:OperationName', default='', namespaces=ns) or '').strip(),
            'ServiceName': (entry.findtext('dm:ServiceName', default='', namespaces=ns) or '').strip(),
            'HttpMethod': (entry.findtext('dm:HttpMethod', default='', namespaces=ns) or '').strip()
        }

        # Check if entry exists in original XML
        xpath_expr = (f"{parent_xpath}/dm:RegexMapEntry"
                      f"[dm:Regex='{delta_values['Regex']}'"
                      f" and dm:ServiceURI='{delta_values['ServiceURI']}'"
                      f" and dm:OperationName='{delta_values['OperationName']}'"
                      f" and dm:ServiceName='{delta_values['ServiceName']}'"
                      f" and dm:HttpMethod='{delta_values['HttpMethod']}']")

        found = original_tree.xpath(xpath_expr, namespaces=ns)
        if not found:
            missing_entries.append(delta_values)

    if missing_entries:
        print(f"Missing entries in Original XML: {missing_entries}")
    else:
        print("All Delta entries exist in Original XML.")

    return missing_entries



def append_delta_to_original(original_xml_path, delta_xml_path, output_path, position="first"):
    """
    Append <dm:RegexMapEntry> nodes from delta XML into the original XML.

    Args:
        original_xml_path (str): Path to original XML
        delta_xml_path (str): Path to delta XML
        output_path (str): Path to save the updated XML
        position (str): 'first' or 'last' to control insertion position
    """
    ns = {'dm': 'http://www.ejada.com/DATA_MAPPING/'}  # Update with your namespace

    # Parse XML files
    original_tree = etree.parse(original_xml_path)
    delta_tree = etree.parse(delta_xml_path)

    # Find the <dm:MAPPING> node in the original XML
    mapping_nodes = original_tree.xpath("//dm:MAPPING", namespaces=ns)
    if not mapping_nodes:
        raise ValueError("No <dm:MAPPING> node found in the original XML.")
    mapping_node = mapping_nodes[0]

    # Find all <dm:RegexMapEntry> in delta XML
    delta_entries = delta_tree.xpath("//dm:MAPPING/dm:RegexMapEntry", namespaces=ns)
    if not delta_entries:
        print("No <dm:RegexMapEntry> found in delta XML. Nothing to append.")
        return

    # Append each delta entry
    for entry in delta_entries:
        # Make a deep copy to insert into original
        entry_copy = etree.fromstring(etree.tostring(entry))
        if position.lower() == "first":
            mapping_node.insert(0, entry_copy)  # Insert at the beginning
        else:  # 'last' or any other value
            mapping_node.append(entry_copy)     # Insert at the end

    # Write updated XML to output_path
    original_tree.write(output_path, pretty_print=True, xml_declaration=True, encoding="utf-8")
    print(f"✅ Delta XML appended to original XML. Saved at: {output_path}")










