import os
import shutil
import xml.etree.ElementTree as ET
from lxml import etree
import copy
import utils.data_mapping as dm
import utils.xml_validator as xv
import utils.rma as rma

TODAY_FOLDER = None




def get_today_folder(folder_name:str):
    """Return the folder for today's date; create it only once."""
    global TODAY_FOLDER
    if TODAY_FOLDER is None:
        TODAY_FOLDER = os.path.join(os.getcwd(), folder_name)
        os.makedirs(TODAY_FOLDER, exist_ok=True)
        print(f"Created folder: {TODAY_FOLDER}")
    return TODAY_FOLDER

def find_file_in_subfolders(root_folder, filename):
    """
    Search recursively in root_folder for filename.
    Returns the first full path found, else None.
    """
    for dirpath, _, files in os.walk(root_folder):
        if filename in files:
            return os.path.join(dirpath, filename)
    return None

def process_sdr_entry(deployment_release_date,domain, target_path, target_files, delta_path,action,xpath,position):
    """
    Example function to process SDR module entries.

    Args:
        localfilepath (str)
        target_path (str)
        target_files (str)
        delta_path (str)
    """

    today_folder = get_today_folder(deployment_release_date)

    nested_folder = os.path.join(today_folder, domain, "delta", target_path)
    os.makedirs(nested_folder, exist_ok=True)
    print(f"Created nested folder: {nested_folder}")


    original_file_path = os.path.join("../","original", "Backup",domain,target_path)
    delta_file_path = os.path.join("../","datapower-prod86", "Deployment","Deployment Packages",delta_path)


    complete_local_file_path = os.path.join(original_file_path, target_files)

    if not os.path.exists(complete_local_file_path):
        print(f"Original file not found: {complete_local_file_path}")
        return

    copied_file_path = os.path.join(nested_folder, target_files)
    if not os.path.exists(copied_file_path):
        shutil.copy2(complete_local_file_path, copied_file_path)
        print(f"Copied {complete_local_file_path} -> {copied_file_path}")
    else:
        print(f"File already copied: {copied_file_path}")



    corrected_delta_path = delta_file_path

    if os.path.isfile(corrected_delta_path):
        print(f"File exists: {corrected_delta_path}")
    else:
        print(f"File does NOT exist: {corrected_delta_path}")
        return

    org_file_path = copied_file_path
    deploy_action_file_path = corrected_delta_path

    print(f"org_file_path: {org_file_path}")
    print(f"deploy_action_file_path : {deploy_action_file_path}")

    if xv.validate_xml_wellformed(org_file_path):
        print("Original XML is valid.")
    else:
        print("Original XML has errors!")
        return

    # Validate deployed/modified XML
    if xv.validate_xml_wellformed(deploy_action_file_path):
        print("Deployment Release XML is valid.")
    else:
        print("Deployment Release XML has errors!")
        return

    if action == "Append" and  target_files == "DATA_MAPPING.XML":
        # Validate delta entries
        results = dm.validate_data_mapping_entries(org_file_path, deploy_action_file_path, xpath)
        if not results:  # Missing entries or validation failed
            print("Delta validation failed. Merge aborted.")
            return False

        # Append delta XML to original
        dm.append_data_mapping_delta_to_original(
            original_xml_path=org_file_path,
            delta_xml_path=deploy_action_file_path,
            output_path=org_file_path,
            position=position
        )

        # Validate merged XML
        if xv.validate_xml_wellformed(org_file_path):
            print("Merged XML is valid.")
            return True
        else:
            print("Merged XML has errors!")
            return False

    if action == "Modify" and  target_files == "DATA_MAPPING.XML":
        results = dm.validate_data_mapping_entries(org_file_path, deploy_action_file_path, xpath)
        if not results:  # Missing entries or validation failed
            print("Delta validation failed. Merge aborted.")
            return False
        update_status = dm.replace_data_mapping_original_entry_if_3_match(org_file_path, deploy_action_file_path)
        if not update_status: print("No updates or modified on the XML files")
        else: print("Modified on the XML files")
        if xv.validate_xml_wellformed(org_file_path):
            print("Modified XML is valid.")
            return True
        else:
            print("Modified XML has errors!")
            return False

    if action == "Delete" and  target_files == "DATA_MAPPING.XML":
        results = dm.validate_data_mapping_entries(org_file_path, deploy_action_file_path, xpath)
        if not results:
            print("Delta validation failed. Merge aborted.")
            return False
        delete_status = dm.delete_data_mapping_original_entry_only_if_all_fields_match(org_file_path, deploy_action_file_path)
        if not delete_status:
            print("No deleting on the XML files")
        else:
            print("Deleted on the XML files")

        if xv.validate_xml_wellformed(org_file_path):
            print("Deleted XML is valid.")
            return True
        else:
            print("Deleted XML has errors!")
            return False

    if action == "Append" and target_files == "RESOURCE_AUTHORIZATION_MAPPING.XML":
        results,testcomments = rma.validate_rma_mapping_attributes(org_file_path, deploy_action_file_path)
        if not results:
            print("Delta validation failed. Merge aborted.")
            return False
        append_status = rma.append_delta_rma_entries(org_file_path, deploy_action_file_path, xpath)
        if not append_status:
            print("No Merge on the original XML files")
        else:
            print("Merged on the original XML files")
            if xv.validate_xml_wellformed(org_file_path):
                print("Merged XML is valid.")
                return True
            else:
                print("Merged XML has errors!")
                return False








