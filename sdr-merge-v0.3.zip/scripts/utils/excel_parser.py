import os
import json
import pandas as pd

def parse_excel_sheet_rows(
    excel_file_path,
    sheet_name,
    output_base_dir="extracted_excel_data"
):
    """
    Parse each row in an Excel sheet into a dictionary and store as JSON files.
    Creates output_base_dir if it does not exist.

    Args:
        excel_file_path (str): Full path to Excel file
        sheet_name (str): Sheet name to parse
        output_base_dir (str): Base directory for extracted data

    Returns:
        str: Output directory path
    """
    if not os.path.exists(excel_file_path):
        raise FileNotFoundError(f"Excel file not found: {excel_file_path}")

    os.makedirs(output_base_dir, exist_ok=True)

    # Load Excel sheet
    df = pd.read_excel(excel_file_path, sheet_name=sheet_name, dtype=str)
    df = df.fillna("")

    df.columns = [col.strip() for col in df.columns]

    for col in df.select_dtypes(include=['object']):
        df[col] = df[col].apply(lambda x: x.strip() if isinstance(x, str) else x)

    excel_name = os.path.splitext(os.path.basename(excel_file_path))[0]

    # Create directory structure: extracted_excel_data/<excel>/<sheet>/
    output_dir = os.path.join(output_base_dir)
    os.makedirs(output_dir, exist_ok=True)

    # Parse rows
    for idx, row in df.iterrows():
        row_dict = row.to_dict()

        output_file = os.path.join(output_dir, f"row_{idx + 1}.json")
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(row_dict, f, indent=4)

    print(f"Parsed {len(df)} rows from sheet '{sheet_name}'")
    print(f"Output directory: {output_dir}")

    return output_dir


