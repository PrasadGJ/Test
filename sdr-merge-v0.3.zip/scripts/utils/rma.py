from lxml import etree
import copy

def validate_rma_mapping_attributes(original_xml_path, delta_xml_path):
    """
    Validate whether ram:MAPPING with ClientID, UserRole, Routing
    from Delta XML exists exactly in Original XML.
    """

    ns = {
        "ram": "http://www.ejada.com/RESOURCE_AUTHORIZATION_MAPPING/"
    }

    # Parse XMLs
    original_tree = etree.parse(original_xml_path)
    delta_tree = etree.parse(delta_xml_path)

    # Get MAPPING nodes from delta
    delta_mappings = delta_tree.xpath("//ram:MAPPING", namespaces=ns)

    if not delta_mappings:
        return "xpath tag not matched"

    # Get all original mappings once
    original_mappings = original_tree.xpath("//ram:MAPPING", namespaces=ns)

    for dmap in delta_mappings:
        d_client = dmap.get("{%s}ClientID" % ns["ram"])
        d_userrole = dmap.get("{%s}UserRole" % ns["ram"])
        d_routing = dmap.get("{%s}Routing" % ns["ram"])

        for omap in original_mappings:
            o_client = omap.get("{%s}ClientID" % ns["ram"])
            o_userrole = omap.get("{%s}UserRole" % ns["ram"])
            o_routing = omap.get("{%s}Routing" % ns["ram"])

            if (
                d_client == o_client and
                d_userrole == o_userrole and
                d_routing == o_routing
            ):
                return True, "clientID,userrole,routing matched with the original files"

    return False ,"RMA xpath tag not matched with original XML"




def append_delta_rma_entries(
    original_xml_path,
    delta_xml_path,
    position="last"
):
    """
    Append delta AUTH_ENTRY nodes into original XML
    when ClientID, UserRole, Routing match exactly.

    position:
        - 'first' : insert at beginning of MAPPING
        - 'last'  : append at end of MAPPING
    """

    ns = {
        "ram": "http://www.ejada.com/RESOURCE_AUTHORIZATION_MAPPING/"
    }

    parser = etree.XMLParser(remove_blank_text=True)

    original_tree = etree.parse(original_xml_path, parser)
    delta_tree = etree.parse(delta_xml_path, parser)

    delta_mappings = delta_tree.xpath("//ram:MAPPING", namespaces=ns)
    original_mappings = original_tree.xpath("//ram:MAPPING", namespaces=ns)

    appended = False

    for dmap in delta_mappings:
        d_client = dmap.get("{%s}ClientID" % ns["ram"])
        d_userrole = dmap.get("{%s}UserRole" % ns["ram"])
        d_routing = dmap.get("{%s}Routing" % ns["ram"])

        delta_auth_entries = dmap.xpath("ram:AUTH_ENTRY", namespaces=ns)

        for omap in original_mappings:
            o_client = omap.get("{%s}ClientID" % ns["ram"])
            o_userrole = omap.get("{%s}UserRole" % ns["ram"])
            o_routing = omap.get("{%s}Routing" % ns["ram"])

            if (
                d_client == o_client and
                d_userrole == o_userrole and
                d_routing == o_routing
            ):
                for entry in delta_auth_entries:
                    entry_copy = copy.deepcopy(entry)

                    if position.lower() == "first":
                        omap.insert(0, entry_copy)
                    else:  # default → last
                        omap.append(entry_copy)

                    appended = True

    if appended:
        original_tree.write(
            original_xml_path,
            pretty_print=True,
            xml_declaration=True,
            encoding="UTF-8"
        )
        print(f"✔ XML updated: {original_xml_path}")
        return True

    return False