import xml.etree.ElementTree as ET

def validate_xml_wellformed(xml_file_path):
    """
    Validate if an XML file is well-formed.

    Args:
        xml_file_path (str): Path to XML file

    Returns:
        bool: True if well-formed, False otherwise
    """
    try:
        ET.parse(xml_file_path)
        #print(f"XML is well-formed: {xml_file_path}")
        return True
    except ET.ParseError as e:
        #print(f"XML is NOT well-formed: {xml_file_path}\nError: {e}")
        return False